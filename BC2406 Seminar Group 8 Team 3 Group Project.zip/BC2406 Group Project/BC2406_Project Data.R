## ============================================================================

## Assignment: BC2406 Group Project
## Seminar/Group : Sem 8 Group 3
## Group Members: Cho Shu Hui, Ho Yao Jiun,Eugene, Peh Wee Din, Su Xin, Tan Xiaoyi Carlyn 

##=============================================================================

library(data.table)
library(rpart)
library(rpart.plot)
library(ggplot2)

setwd("C:/Users/chosh/OneDrive/Documents/_BC2406 Analytics I - Visual & Predictive Techniques/Group Project/BC2406 Group Project")

options(scipen = 100) 

## Cleaning of Data ============================================================
# Government Operating Revenue
gdata2 <- fread("Gov Operating Expenditure.csv", na.strings = c("na"))
summary(gdata2$Culture_Community_And_Youth)
gdata2[is.na(gdata2$Culture_Community_And_Youth), Culture_Community_And_Youth:=402.5]

# Government Development Expenditure
gdata3 <- fread("Gov Development Expenditure.csv",na.strings = c("na"))
summary(gdata3$Culture_Community_And_Youth)
gdata3[is.na(gdata3$Culture_Community_And_Youth), Culture_Community_And_Youth:=99.81]



## Overall GDP =====================================================================

#Linear Regression model
data1 <- fread("GDP Breakdown (CIGX).csv")
linreg1 <- lm(GDP ~ . -Year, data=data1)
summary(linreg1)

# CART
summary(data1)
cart1<-rpart(GDP~.-Year,data=data1,method="anova")
printcp(cart1)
plotcp(cart1)
rpart.plot(cart1,main="Maximal Tree")
cp1 <- sqrt(0.070537*0.732806)
cart2<-prune(cart1,cp1)
rpart.plot(cart2,main="Optimal tree for factors affecting GDP ")
cart2$variable.importance
summary(cart2)


## Net exports (Machine + Commodity) ===========================================
# CART
data2<-fread("Net Exports.csv")
cart3<-rpart(GDP~.-Year,data=data2,method="anova")
printcp(cart3)
plotcp(cart3)
cp2 <- sqrt(0.089965*0.777267)
cart4<-prune(cart3,cp2)
rpart.plot(cart4,main="Optimal tree for net exports")
cart4$variable.importance
summary(cart4)


## CHARTS ======================================================================

# Chart for GDP components by variable importance
Components <- c("Net_Exports_Of_Goods_and_Services", "Government_Consumption_Expenditure", 
             "Private_Consumption_Expenditure", "Gross_Fixed_Capital_Formation")
Weightage <- c(34, 23, 23, 19)

data.df <- data.frame(Components, Weightage)
ggplot(data.df, aes(x=Components, y=Weightage))+
  geom_bar(stat="identity", color="skyblue", fill="skyblue" )+
  labs(title = "Distribution of Variable Importance of GDP Components", 
       y="Weightage (%)", x="Components of GDP")+
  geom_text(aes(label=Weightage), vjust=-0.2)


# Chart for Breakdown of Net Exports by variable importance
Components_NX <- c("Chemicals_and_Chemical_Products", "Manufactured_Goods", "Disk_Drives",
                 "Machinery_and_Transport_Equipment", "Parts_Of_Personal_Computer", 
                 "Beverages_and_Tobacco")

Weightage_NX <- c(20, 18, 16, 16, 15, 14) 

dataNX.df <- data.frame(Components_NX, Weightage_NX)
ggplot(dataNX.df, aes(x=Components_NX, y=Weightage_NX))+
  geom_bar(stat="identity", color="skyblue", fill="skyblue" )+
  labs(title = "Distribution of Variable Importance of Net Export Components", 
       y="Weightage (%)", x="Components of Net Exports")+
  geom_text(aes(label=Weightage_NX), vjust=-0.2)


